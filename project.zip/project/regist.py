# coding = utf-8
"""
注册模块
用户密码采取sha1加密存入数据库,保护用户隐私
"""
#注册的新用户放入数据库中
from mysqlpython2 import *
from hashlib import sha1

class User_Regist():
    def __init__(self,db):
        # self.user_name = user_name
        # self.user_pwd = user_pwd
        self.database = db
        self.db1 = Mysqlpython2(self.database)
        # self.judge()
        
    def judge(self,user_phone,user_pwd):
        if len(user_phone) <= 15:
            #判断用户名是否已经存在
            sel = "select * from user where user_phone = '%s'"%user_phone
            # print(user_phone)
            data = self.db1.select_file(sel)
            # print('注册data',data)
           
            if data:
                print("用户已存在")
                return False
            else:
                result = self.do_regist(user_phone,user_pwd)
                if result:
                    return True
                else:
                    return False
        else:
            print("用户名太长,请重试!")
            return
    
    def do_regist(self,user_phone,user_pwd):
        if len(user_pwd) <= 12:
            s1 = sha1()
            s1.update(user_pwd.encode("utf8"))      # sha1.update() 要求输入的必须是二进制
            pwd2 = s1.hexdigest()              # 返回16进制加密结果
            ins = "insert into user(user_phone,pwd) values('%s','%s')"% (user_phone,pwd2)
            data = self.db1.start_file(ins)
            if not data:
                return False
            else:
                return True
        else:
            print("密码太长,请重试")
            return False





if __name__ == "__main__":
    user_phone = input("请输入用户名(长度不超过15):")
    user_pwd = input("请输入密码(12位以内):")

    user1 = User_Regist("project")
    data = user1.judge(user_phone,user_pwd)
    print(data)
    






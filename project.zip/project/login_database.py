#encoding=utf-8

'''将房屋信息信息导入数据库'''
# create table houseinfo( id int primary key auto_increment, 
# address varchar(60), info text,charge int);
# #

# create table beilin(
#     id int primary key auto_increment,
#     miaoshu text,
#     village varchar(30),
#     price varchar(10),
#     address varchar(70)
# );


from mysqlpython2 import *


def main():
    db1 = Mysqlpython2("project")
    f=open('beilin.csv')
    lines = f.readlines()
    for line in lines:
        # print(line)
        miaoshu=line.split("#")[0]
        village = line.split("#")[1]
        price = line.split("#")[2]
        address = line.split("#")[3]
        # print("info:",address,"!!!",name,"!!",price)
        ins = "insert into beilin(miaoshu,village,price,address) values('%s','%s','%s','%s')"%(miaoshu,village,price,address)
        values = db1.start_file(ins)
        if values is None:
            print("插入失败")
            return
    print("插入完成")



if __name__=="__main__":
    main()
    



# -*- coding: utf-8 -*-
import urllib.request
import urllib.parse
import random

class ZhenziSmsClient(object):
	def __init__(self, apiUrl='http://sms_developer.zhenzikj.com', 
				appId='100129', 
				appSecret='YTUzNDM4MWItZmVmNC00ZTM3LWI1ZDMtNzVjZDYyZTMzMGQy'):
		self.apiUrl = apiUrl
		self.appId = appId
		self.appSecret = appSecret

	def send(self, number, message, messageId=''):
		data = {
    	    'appId': self.appId,
		    'appSecret': self.appSecret,
		    'message': message,
		    'number': number,
		    'messageId': messageId
		}
        
		data = urllib.parse.urlencode(data).encode('utf-8');
		req = urllib.request.Request(self.apiUrl+'/sms/send.do', data=data);
		res_data = urllib.request.urlopen(req);
		res = res_data.read();
		res = res.decode('utf-8');
		return res;


	def balance(self):
		data = {
		    'appId': self.appId,
		    'appSecret': self.appSecret
		}
		data = urllib.parse.urlencode(data).encode('utf-8');
		req = urllib.request.Request(self.apiUrl+'/account/balance.do', data=data);
		res_data = urllib.request.urlopen(req);
		res = res_data.read();
		return res;

if __name__=="__main__":
	zhenzi = ZhenziSmsClient()
	number = input("请输入您的手机号:")
	sim = random.sample(list(range(0,9)),4)
	sim = list(map(lambda x:str(x),sim))
	sim = "".join(sim)
	message = "您的验证码为%s"%sim
	
	print(message)
	msg = zhenzi.send(number,message)
	print("msg:",msg)
	data1 = zhenzi.balance()
	print(data1)


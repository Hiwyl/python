#  用户登录程序

from mysqlpython2 import *
from hashlib import sha1

class User_Login():
    def __init__(self,db):
        # self.name = name
        # self.pwd = pwd
        self.database = db
        self.db1 = Mysqlpython2(self.database)
        # self.judge1()

    def judge1(self,user_phone,pwd):
        s1 = sha1()
        s1.update(pwd.encode("utf8"))
        pwd2 = s1.hexdigest()
        # print(pwd2)
        sel = "select * from user where user_phone = '%s' and pwd = '%s'" % (user_phone,pwd2)
        data = self.db1.select_file(sel)
        # print('login.data',data)
        if data:
            return True
        else:
            print("用户不存在!")
            return False

    # 从session和cookies中的到的数据
    def judge2(self,user_phone,pwd):
        sel = "select * from user where user_phone = '%s' and pwd = '%s'" % (user_phone, pwd)
        data = self.db1.select_file(sel)
        # print('login.data',data)
        if data:
            return True
        else:
            print("用户不存在!")
            return False

if __name__ == "__main__":
    name = input("请输入用户名:")
    pwd = input("请输入密码:")
    user = User_Login('dictionary')
    data = user.judge1(name,pwd)
    print(data)
    






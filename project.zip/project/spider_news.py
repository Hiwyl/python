#encoding=utf8

import requests
from bs4 import BeautifulSoup
import schedule
import time
import csv
headers = {
 # 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'
 "User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"
}

def getHTMLText(url):
    try:
        r = requests.get(url,headers=headers,timeout=30)
        print("-----",r)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        return '产生异常'

def get_data(list,html):
    soup = BeautifulSoup(html,'html.parser')
    # print(soup)
    print("****************************")
    infos = soup.find('ul', {'id': 'BiDu'}).find_all('li')
    # print("+-+-+-+-",infos)
    with open('/home/tarena/aid1808/linux/xiangmu/project/news.csv', 'w', encoding='utf-8') as f:
        for info in infos:
            titles = info.find('div',{'class','list-right'})
            print(titles)
            titles = titles.find('a').get_text()
            address = info.find('div',{'class','list-right'}).a['href']
            f.write("{}#{}\n".format(titles,address))


def main():
    # start_url = 'http://zhishi.fang.com/zf/f%s/'
    depth = 2
    info_list =[]
    for i in range(1,depth):
        # url = start_url + str(i)
        url = 'http://zhishi.fang.com/zf/f%s/'% str(i)
        print(url)
        html = getHTMLText(url)
        get_data(info_list,html)

# schedule.every().day.at("08:30").do(main)
# while True:
#     schedule.run_pending()
#     time.sleep(30)


# main()


def spider_new(address):
    address = "http:"+address
    # print(address)
    html = getHTMLText(address)
    soup = BeautifulSoup(html, 'html.parser')
    print("----------*************")
    # print(soup)
    times = soup.find('div',{'class':'top1'}).find('div',{'class':'essay'}).find('p',{'class':'essay_author'}).find('span',{'class':'time'}).get_text()
    zhaiyao = soup.find('div',{'class':'top1'}).find('div',{'class':'essay'}).find("div",{'class':'essay_abstract'}).get_text()
   
    return times,zhaiyao



def spider_news(address):
    address = "http:"+address
    # print(address)
    html = getHTMLText(address)
    soup = BeautifulSoup(html, 'html.parser')
    print("----------*************")
    # print(soup)
    titles = soup.find('div',{'class':'top1'}).find('div',{'class':"essay"}).find('h1').get_text()
    print(titles)
    times = soup.find('div',{'class':'top1'}).find('div',{'class':'essay'}).find('p',{'class':'essay_author'}).find('span',{'class':'time'}).get_text()
    zhaiyao = soup.find('div',{'class':'top1'}).find('div',{'class':'essay'}).find("div",{'class':'essay_abstract'}).get_text()
    # print(zhaiyao)
    news = soup.find('div',{'class':'top1'}).find('div',{'class':'essay'}).find("div",{'class':'essay_zw'}).get_text()
    return titles,times,zhaiyao,news








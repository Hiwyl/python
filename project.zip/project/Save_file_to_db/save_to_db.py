#encoding=utf-8

'''将房屋信息信息导入数据库
    在执行导入时 先要保证models执行一次  数据库中有对应的表
    需要在当前目录下存在csv,
    你的数据库名称应该是project
    需要导入其他csv时，请将 所有的名字更换！！！！  et： 全部的：  beilin --> yanta

    这两句
    f=open('beilin.csv',encoding='utf8')
    ins = "insert into beilin(miaoshu,village,price,address) values('%s','%s','%s','%s')"%(miaoshu,village,price,address)
'''

from connect_db import Mysqlpython2

def main():
    db1 = Mysqlpython2("project")
    f=open('yanta.csv',encoding='utf8')
    lines = f.readlines()
    for line in lines:
        miaoshu=line.split("#")[0]
        village = line.split("#")[1]
        price = line.split("#")[2]
        address = line.split("#")[3]
        # print("info:",address,"!!!",name,"!!",price)
        ins = "insert into yanta(miaoshu,village,price,address) values('%s','%s','%s','%s')"%(miaoshu,village,price,address)
        values = db1.start_file(ins)
        if values is None:
            print("插入失败")
            return
    print("插入完成")



if __name__=="__main__":
    main()
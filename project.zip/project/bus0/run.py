import json

import requests
from flask import Flask, request, render_template, redirect

app = Flask(__name__)

@app.route("/position",methods=["GET","POST"])
def get_position():
    if request.method == "GET":
        return render_template("position.html")
    else:
        #获取用户输入
        first=request.form.get("first")
        end= request.form.get("end")
        #判断用户需求
        if request.form.get("path"):
            #　查询公共交通
            return render_template("path.html",params=locals())
        elif request.form.get("byCar"):
            # 查询自驾路线
            return render_template("byCar.html", params=locals())
        elif request.form.get("weather"):
            # 查天气
            return render_template("weather.html")
        elif request.form.get("pol"):
            # 查询周边pol
            # 网站请求获取目的地经纬度
            url='http://api.map.baidu.com/geocoder/v2/?&'
            address='address='+end+'&city=西安市&'
            output ='output='+'json&'
            ak = 'ak='+'yxsRkAB6HHuHdILIBVHxKDKV2VNG8qZL&'
            callback = 'callback='+'showLocation'
            # 拼接完整url
            full_url=url+address+output+ak+callback


            # 向网站请求，返回网站回应的response对象
            response = requests.get(full_url)

            # 使用loads()将json字符串转换成字典类型
            rs=response.text[27:-1]

            rs_dict = json.loads(rs)
            print(rs_dict)

            # 根据网站的API接口说明，error为0表示数据正常
            error_code = rs_dict['status']
            print(error_code)

            if error_code == 0:
                # 对数据的处理完全由返回JSON的内部结构和键值决定
                lng = rs_dict["result"]['location']["lng"]
                lat = rs_dict["result"]['location']["lat"]
                return render_template("pol.html",params=locals())
            else:
                return "输入错误"

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
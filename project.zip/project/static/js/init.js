function $2(tagName){
    var elems = document.getElementsByTagName(tagName);
    return elems;
}

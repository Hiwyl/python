
# 导入pymysql模块
from pymysql import *

# 定义类
class Mysqlpython2:
    def __init__(self,database,host='localhost',user='root',password='123456',
                charset='utf8',port=3306):
        self.database=database
        self.host=host
        self.user=user
        self.password=password
        self.charset=charset
        self.port=port
    # 创建数据库连接对象
    def open_file(self):
        try:
            self.db=connect(host=self.host,user=self.user,password=self.password,
                        database=self.database,charset=self.charset,port=self.port)
            # 利用数据库对象创建游标对象
            self.cur=self.db.cursor()
        except Exception as err:
            print("打开文件失败",err)
    # 断开与数据库的连接
    def close_file(self):
        self.cur.close()
        self.db.close()
    # 执行sql语句，sql形参传入的是sql执行语句
    def start_file(self,sql,L=[]):
        self.open_file()
        try:
            self.cur.execute(sql,L)
            self.db.commit()
        except Exception as err:
            print("执行失败",err)
            self.db.rollback()
            return
        self.close_file()
        return "OK"
    # 执行sql查找语句，sql形参传入的是sql执行语句，并返回所有查找结果    
    # def select_file(self,sql,t=[]):
    def select_file(self,sql):
        self.open_file()
        try:
            self.cur.execute(sql)
            result = self.cur.fetchall()
            # print(result)
            return result
        except Exception as err:
            print("读取文件失败",err)
            return
# 测试代码
if __name__=="__main__":
    sqlh = Mysqlpython2("db5")
    # n = input("请输入姓名:")
    # s = input("请输入成绩:")
    # zx = 'insert into t1(name,score) values(%s,%s);'
    # sqlh.start_file(zx,[n,s])

    n1 = 'name'
    s1 = 'score'
    cz1='select %s,%s from t1;'
    l=sqlh.select_file(cz1,[n1,s1])
    print(l)

    n = '李白'
    s = '100'
    cz='select * from t1 where name=%s and score=%s;' 
  
    l=sqlh.select_file(cz,[n,s])
    print(l)
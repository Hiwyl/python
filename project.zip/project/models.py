from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import pymysql
pymysql.install_as_MySQLdb()
from datetime import datetime
from hashlib import sha1

app = Flask(__name__)
# 为app指定数据库的配置信息
app.config['SQLALCHEMY_DATABASE_URI' ] ='mysql://root:123456@localhost:3306/project'
db = SQLAlchemy(app)

app.config['SECRET_KEY']="zheshimiyao"

'''
    首先保证你的数据库名为project  编码为utf-8
'''

class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    user_phone = db.Column(db.String(11))
    pwd = db.Column(db.String(60))
    zctime = db.Column(db.DateTime, default=datetime.now)

    def __init__(self,phone,pwd,zctime=datetime.now()):
        self.user_phone = phone
        self.pwd = pwd
        self.zctime = zctime

# `id` int(11) NOT NULL AUTO_INCREMENT,
#   `name` varchar(30) DEFAULT NULL,
#   `pwd` varchar(20) DEFAULT NULL,
#   `userph` char(11) DEFAULT NULL,

class History(db.Model):
    __tablename__ = "history"
    id = db.Column(db.Integer ,primary_key=True)
    uname = db.Column(db.String(20) ,nullable = False)
    miaoshu = db.Column(db.Text)
    village = db.Column(db.String(30))
    price = db.Column(db.String(10))
    address = db.Column(db.String(70))
    cktime = db.Column(db.DateTime)

    def __init__(self ,uname ,miaoshu ,village ,price ,address):
        self.uname = uname
        self.miaoshu = miaoshu
        self.village = village
        self.price = price
        self.address = address


    def __repr__(self):
        return "<History:%r>" % self.uname

# create table beilin(
#     id int primary key auto_increment,
#     miaoshu text,
#     village varchar(30),
#     price varchar(10),
#     address varchar(70)
# );
class Yanta(db.Model):
    __tablename__ = "yanta"
    id = db.Column(db.Integer ,primary_key=True)
    miaoshu = db.Column(db.Text)
    village = db.Column(db.String(30))
    price = db.Column(db.String(10))
    address = db.Column(db.String(70))

    def __init__(self ,miaoshu ,village ,price ,address):
        self.miaoshu = miaoshu
        self.village = village
        self.price = price
        self.address = address

    def __repr__(self):
        return "<Yanta:%r>" % self.miaoshu

class Beilin(db.Model):
    __tablename__ = "beilin"
    id = db.Column(db.Integer ,primary_key=True)
    miaoshu = db.Column(db.Text)
    village = db.Column(db.String(30))
    price = db.Column(db.String(10))
    address = db.Column(db.String(70))

    def __init__(self ,miaoshu ,village ,price ,address):
        self.miaoshu = miaoshu
        self.village = village
        self.price = price
        self.address = address

    def __repr__(self):
        return "<Beilin:%r>" % self.miaoshu
    

class Comment(db.Model):
    __tablename__="comment"
    id = db.Column(db.Integer,primary_key=True)
    uname = db.Column(db.String(20))
    pingl = db.Column(db.Text)
    ptime = db.Column(db.DateTime,default=datetime.now)

    def __init__(self,uname,pingl):
        self.uname = uname
        self.pingl = pingl
    def __repr__(self):
        return "<Comment:%r>" % self.uname


class Otherhouse(db.Model):
    __tablename__ = "otherhouse"
    id = db.Column(db.Integer ,primary_key=True)
    miaoshu = db.Column(db.Text)
    village = db.Column(db.String(30))
    price = db.Column(db.String(10))
    address = db.Column(db.Integer,nullable=True)

    def __init__(self ,miaoshu ,village ,price):
        self.miaoshu = miaoshu
        self.village = village
        self.price = price
        

    def __repr__(self):
        return "<Otherhouse:%r>" % self.miaoshu




if __name__ == '__main__':
    db.create_all()
    # use = User('chen','123')
    # db.session.add(use)
    # db.session.commit()

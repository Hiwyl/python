#encoding = utf-8



from flask import Flask, request, render_template, redirect, url_for, session
from regist import *
from login import *
from message import *
import random
import json
from hashlib import sha1
from sqlalchemy import or_
from spider_news import *
from models import *
import requests

L =[]



@app.route("/",methods=['GET','POST'])
# @app.route("/hello",methods=['GET','POST'])
def hello():
    print("hello")
    if request.method == "GET":
        return render_template("hello.html")

#  租房主页,登录页面请求
@app.route("/zufang",methods=['GET','POST'])
def login_zy():
    if request.method == "GET":
        # print("zufang")
        if 'upwd' in session and 'uname' in session:
            # 已经成功刚登录过
            user_pwd = session.get("upwd")
            user_phone = session.get("uname")
            user = User.query.filter(User.user_phone==user_phone,User.pwd==user_pwd).first()
            # print(user.judge1(user_phone, user_pwd))
            if user:
                return redirect(url_for('islogin', uname=user_phone))
            else:
                msg = '用户名或密码错误'
                return render_template('zufang.html', msg=msg)
        else:
            # 没有在登录状态上
            # 判断cookies是否有登录信息
            if "upwd" in request.cookies and "uname" in request.cookies:
                # cookies中有登录信息,从cookies中取出来数据保存进session,并重定向回首页
                user_pwd = request.cookies['upwd']
                user_phone = request.cookies['uname']
                user = User.query.filter(User.user_phone==user_phone,User.pwd==user_pwd).first()
                # print(user.judge1(user_phone, user_pwd))
                if user:
                    session['upwd'] = user_pwd
                    session['uname'] = user_phone
                    return redirect(url_for('islogin', uname=user_phone))
                else:

                    # 需要再处理,删除cookie中的错误信息

                    msg = '用户名或密码错误'
                    return render_template('zufang.html', msg=msg)

            else:
                # cookies中也没有登录信息
                return render_template("zufang.html")
    # 登录的请求
    else:
        user_phone = request.form.get('uphone')
        user_pwd = request.form.get("upwd")
        if not user_phone or not user_pwd:
            msg = "用户名或密不能为空"
            return render_template("zufang.html",msg=msg)
        elif user_phone == "admin" and user_pwd == "123456":
            return redirect("/glylogin")
        else:
            print(user_phone)
            print(user_pwd)
            s1 = sha1()
            s1.update(user_pwd.encode("utf8"))
            pwd2 = s1.hexdigest()
            user = User.query.filter(User.user_phone==user_phone,User.pwd==pwd2).first()
            # print(user.judge1(user_phone,user_pwd))
            if user:
                # 用户名密码正确,保存密码
                if 'savepwd' in request.form:
                    session['uname'] = user_phone
                    session["upwd"] = pwd2
                return redirect(url_for('islogin',uname=user_phone))
            else:
                msg = '用户名或密码错误'
                return render_template('zufang.html',msg=msg)


#管理员页第一次请求
@app.route("/glylogin",methods=['GET','POST'])
def admin_login():
    if request.method == "GET":
        names = "管理员"
        # result = quary_all('beilin')
        result = Beilin.query.all() + Yanta.query.all()

        return render_template('glylogin.html',result=result,names=names)
  
    else:
        names = "管理员"
        miaoshu = request.form.get("miaoshu")
        xiaoqu = request.form.get("xiaoqu")
        price = request.form.get("price")
        print(miaoshu,xiaoqu,price)
        
        if miaoshu and xiaoqu and price:
            house = Otherhouse(miaoshu,xiaoqu,price)
            try:
                db.session.add(house)
                db.session.commit()
            except Exception:
                msg = "加入房源失败,请稍后再试"
            else:
                msg = "加入房源成功"
            finally:
                return render_template('/glylogin.html',names=names,msg=msg)
            
    
        else:
            msg = "房屋信息不能为空"
            return render_template('/glylogin.html',names=names,msg=msg)

#处理手机验证码请求
@app.route("/regist1",methods=["POST"])
def send_msg():
    print('进入ajax--post')
    uname = request.form["uphone"]
    # uname = request.form.get("uphone")
    print(uname)
    sim1 = random.sample(list(range(0,9)),4)
    sim1 = list(map(lambda x:str(x),sim1))
    # global sim
    sim = "".join(sim1)
    L.append(sim)
    message = "您的验证码为:%s" % sim
    zhenzi = ZhenziSmsClient()
    msg = zhenzi.send(uname,message)
    print(message)
    print("msg:",msg)
    return json.dumps(msg)


#注册请求
@app.route("/regist",methods=["GET","POST"])
def register():

    if request.method == 'GET':
        print("获取GET请求")
        return render_template('regist.html')
    else:
        print("------")
        print(L)
        uname = request.form.get("uphone")
        upwd = request.form.get("upwd")
        uword = request.form.get("yanzhengma")
        if not uname or not upwd:
            msg = '用户名或密码不能为空'
            return render_template('regist.html', msg=msg)
        elif uword != L[-1]:
            msg = '验证码错误'
            return render_template('regist.html', msg=msg)
        else:
            if L:
                n = L.pop()
            # user1 = User_Regist("project")
            user1 = User.query.filter(User.user_phone == uname).first()
            if user1:
                msg = '用户名已存在'
                return render_template('regist.html', msg=msg)

            else:
                s1 = sha1()
                s1.update(upwd.encode("utf8"))
                pwd2 = s1.hexdigest()
                user2 = User(uname,pwd2)
                db.session.add(user2)
                db.session.commit()
                return redirect('/zufang')

#登陆成功之后请求
@app.route('/islogin/<uname>',methods=["GET","POST"])
def islogin(uname):
    if request.method =='GET':
        print("get请求")
        kw = request.args
        distict = kw.get('distict')
        print(type(distict))
        if distict=='1' :
            result = Beilin.query.all()
            name = []
            num = []
            if result:
                for i in result:
                    name.append((i.village).strip())
                    num.append(int(i.price))
            return render_template('islogin.html',result=result,name=name,num=num,uname=uname)
        elif distict == "2":
            print("-----")
            result = Yanta.query.all()
            name = []
            num = []
            if result:
                for i in result:
                    name.append((i.village).strip())
                    num.append(int(i.price))
            return render_template('islogin.html', result=result, name=name, num=num, uname=uname)
        else:
            print("未选择区域")
            result = Beilin.query.all()[:5]
            name = []
            num = []
            if result:
                for i in result:
                    name.append((i.village).strip())
                    num.append(int(i.price))
            return render_template('islogin.html',result=result,name=name,num=num,uname=uname)
    else:
        print("查询请求")
        txt = request.form.get("txt")
        print("----")
        print(txt)
        txt1 = "%"+txt+"%"
        result = db.session.query(Beilin).filter(or_(Beilin.miaoshu.like(txt1),Beilin.village.like(txt1))).all()
        # print(result)
        result += db.session.query(Yanta).filter(or_(Yanta.miaoshu.like(txt1),Yanta.village.like(txt1))).all()
        # print(result)
        name = []
        num = []
        if result:
            for i in result:
                name.append((i.village).strip())
                num.append(int(i.price))
        print(name)
        print(num)
        return render_template('islogin.html',result=result,name=name,num=num,uname=uname)



#管理员操作删除请求
@app.route('/shanchu',methods = ['POST'])
def delete_info():
    print("删除")
    names = "管理员"
    nameID = request.form.get('id')
    miaoshu = request.form.get("miaoshu")
    village = request.form.get("village")
    price = request.form.get("price")

    print(nameID,miaoshu,price)
    # result = delete_house(nameID)
    result = db.session.query(Beilin).filter(Beilin.id==nameID,Beilin.miaoshu==miaoshu,Beilin.village==village,Beilin.price==price).first()
    print(result)
    if result:
        db.session.delete(result)
        db.session.commit()
        msg = "删除成功"
        print("1")
        return render_template('/glylogin.html',names=names,msg=msg)
    elif not result:
        result = db.session.query(Yanta).filter(Yanta.id==nameID,Yanta.miaoshu==miaoshu,Yanta.village==village,Yanta.price==price).first()
        if result:
            db.session.delete(result)
            db.session.commit()
        msg = "删除成功"
        print("2")
        return render_template('/glylogin.html',names=names,msg=msg)
    # if result:
    #     msg = "删除成功"
    #     return render_template('/glylogin.html',names=names,msg=msg)
    else:
        msg = "删除失败,请重试"
        return render_template('/glylogin.html',names=names,msg=msg)



# #打开模板页参数准备
@app.route("/moban1",methods=["GET"])
def open_moban():
    print("准备打开模板文件")
    datas = request.args.get("id")
    print(datas)
    data = datas.split("#*#")
    miaoshu = data[0]
    xiaoqu = data[1]
    jiage = data[2]
    uname = data[3]
    address = data[4]
    res = db.session.query(History).filter(History.uname==uname,History.miaoshu==miaoshu,History.village==xiaoqu,History.price==jiage).first()
    if res:
        db.session.delete(res)
        user = History(uname,miaoshu,xiaoqu,jiage,address)
        db.session.add(user)
        db.session.commit()
    # add_house(uname,miaoshu,xiaoqu,jiage,address)
    else:
        user = History(uname, miaoshu, xiaoqu, jiage, address)
        db.session.add(user)
        db.session.commit()
    print("插入完成")
    return datas


# 跳转模板页打开模板html加入数据
@app.route("/islogin/moban",methods=["GET"])
def open_mobanHtml():
    print("打开html")
    result = db.session.query(History).order_by("id desc").first()
    # result = moban_info()[0]
    # print(result)
    uname = result.uname
    miaoshu = result.miaoshu
    xiaoqu = result.village
    jiage = result.price
    return render_template('/moban.html',xiaoqu = xiaoqu,miaoshu=miaoshu,jiage=jiage,uname=uname)

@app.route('/about',methods=["GET","POST"])
@app.route('/islogin/about',methods=["GET","POST"])
def about():
    if request.method == "GET":
        uname = request.args.get('name')
        print("aboutname:",uname)
        result = db.session.query(History).filter(History.uname==uname).order_by('id desc').limit(5).all()
        print(result)
        return render_template('/about.html',uname=uname,result=result)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'),404

@app.route('/leacots',methods=['GET','POST'])
def leacots():
    if request.method=="GET":
        uname = request.args.get('uname')
        comms = Comment.query.order_by('id desc').all()
        lenth = len(comms)
        return render_template('leacots.html',uname=uname,comms=comms,lenth = lenth)
    else:
        uname = request.form.get('username')
        comment = request.form.get('desc')
        print("uname:",uname)
        print("comment",comment)

        comments = Comment(uname,comment)
        db.session.add(comments)
        db.session.commit()
        comms = Comment.query.order_by('id desc').all()
        # comms = db.session.query(Comment).order_by("id desc").all()
        # print(comms)
        lenth = len(comms)
        return render_template('leacots.html',uname=uname,comms=comms,lenth = lenth)


@app.route('/index')
def index():
    uname = request.args.get('uname')
    with open('./news.csv','r')as f:
        #　二维列表存储新闻简体
        
        L2 = []
        lines = f.readlines()
        for line in lines:
            L1=[]
            line = line.split("#")
            titles = line[0]
            address = line[1]
            # print(titles)
            times, zhaiyao = spider_new(address)
            L1.append(titles)
            L1.append(times)
            L1.append(zhaiyao)
            L1.append(address)
            L2.append(L1)
        print(L2)
        return render_template('index.html',L2 = L2,uname=uname)


@app.route('/news')
def news_views():
    address = request.args.get('address')
    uname = request.args.get('uname')
    titles,times,zhaiyao,news = spider_news(address)
    return render_template('news.html',uname = uname,titles=titles,times=times,zhaiyao=zhaiyao,news=news)


@app.route("/position",methods=["GET","POST"])
def get_position():
    
    if request.method == "GET":
        uname = request.args.get("uname")
        return render_template("position.html",uname=uname)
    else:
        #获取用户输入
        uname = request.form.get('uname')
        print("position",uname)
        first=request.form.get("first")
        end= request.form.get("end")
        #判断用户需求
        if request.form.get("path"):
            #　查询公共交通
            return render_template("path.html",params=locals())
        elif request.form.get("byCar"):
            # 查询自驾路线
            return render_template("byCar.html", params=locals())
        elif request.form.get("weather"):
            # 查天气
            return render_template("weather.html", params=locals())
        elif request.form.get("pol"):
            # 查询周边pol
            # 网站请求获取目的地经纬度
            url='http://api.map.baidu.com/geocoder/v2/?&'
            address='address='+end+'&city=西安市&'
            output ='output='+'json&'
            ak = 'ak='+'yxsRkAB6HHuHdILIBVHxKDKV2VNG8qZL&'
            callback = 'callback='+'showLocation'
            # 拼接完整url
            full_url=url+address+output+ak+callback


            # 向网站请求，返回网站回应的response对象
            response = requests.get(full_url)

            # 使用loads()将json字符串转换成字典类型
            rs=response.text[27:-1]

            rs_dict = json.loads(rs)
            print(rs_dict)

            # 根据网站的API接口说明，error为0表示数据正常
            error_code = rs_dict['status']
            print(error_code)

            if error_code == 0:
                # 对数据的处理完全由返回JSON的内部结构和键值决定
                lng = rs_dict["result"]['location']["lng"]
                lat = rs_dict["result"]['location']["lat"]
                return render_template("pol.html",params=locals())
            else:
                return "输入错误"



@app.route('/logout')
def logout():
    resp = redirect('/zufang')
    if "uname" in session and "upwd" in session:
        del session['uname']
        del session['upwd']
    if "uname" in request.cookies and 'upwd' in request.cookies:
        resp.delete_cookie('uname')
        resp.delete_cookie('upwd')
    return resp







if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)



